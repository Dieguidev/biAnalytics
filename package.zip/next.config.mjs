/** @type {import('next').NextConfig} */
const nextConfig = {
  // output: 'export',
  // distDir: 'out',
  // images: {
  //   unoptimized: true, // Desactiva la optimización de imágenes de Next.js para exportaciones estáticas
  // },
};

export default nextConfig;
